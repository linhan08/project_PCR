package com.ifisolution.realtimeprc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealtimePrcApplicationTests {
}
