package com.ifisolution.realtimeprc.repository;

import com.ifisolution.realtimeprc.domain.model.EmployeeResult;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeResultRepo extends JpaRepository<EmployeeResult,Integer> {
}
