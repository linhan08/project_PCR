import { Component, OnInit } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { Signup } from '../model/signup.model';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signModel: Signup = new Signup();

  constructor(private authService: AuthService) { }

  ngOnInit() {
  }

  signupUser() {
    this.authService.register(this.signModel).subscribe(data => {
      console.log(data);
    }, err => {
      console.log(err);
    });
  }

}
