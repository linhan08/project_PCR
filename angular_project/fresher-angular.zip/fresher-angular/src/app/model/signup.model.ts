export class Signup {
  username: string;
  email: string;
  password: string;
  role = ['user'];
}
